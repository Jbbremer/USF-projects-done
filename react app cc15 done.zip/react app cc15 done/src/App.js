// creaating function for skill and proficiency list
function Skill(props) {
  const { name, proficiency } = props;

  return (
    <div className="skill">
      <span className="skill-name" >{name}</span>
      <span className="skill-proficiency">Proficiency:  {proficiency}</span>
    </div>
  );
}
//creating function for job list
function JobExperiences({ jobTitle, companyName, duration }) {
  return (
    <div className="experience-entry">
      <h3>{jobTitle}</h3>
      <p>{companyName} - {duration}</p>
    </div>
  );
}
// creating function for education list
function Education({ institutionName, degree, yearsAttended }) {
  return (
    <div className="education-entry">
      <h3>{institutionName}</h3>
      <p>{degree} - {yearsAttended} Years</p>
    </div>
  );
}
// Generate a random age between 18 and 70 for bio because I can.
const age = Math.floor(Math.random() * (70 - 18 + 1)) + 18;

// creating user
const user = {
 name: "Anonymous User",
 bio: `Anonymous User, Lives Somewhere on Earth, Does mostly boring stuff,  a possible  age: ${age} ` ,
 email: "AnonUser@obviouslyFakeAddress.com"
}
// creating skill list array
const skills = [
  { name: "JavaScript ", proficiency: "Poor" },
  { name: "React ", proficiency: "Poor" },
  { name: "HTML ", proficiency: "Poor" },
  { name: "CSS ", proficiency: "Poor" }
];
// Creating other arrays
const experiences = [
  { jobTitle: "Job 1", companyName: "Company 1", duration: "1 Year" },
  { jobTitle: "Job 2", companyName: "Company 2", duration: "2 Years" },
  { jobTitle: "Job 3", companyName: "Company 3", duration: "3 Years" }
];

const education = [
  { institutionName: "Local County College", degree: "Associates in Business", yearsAttended: 2 },
  { institutionName: "State University 1", degree: "Not Achieved", yearsAttended: 1 }
];
// export and display
export default function Profile() {
  return(
  <><>
      <h1><u>About: {user.name}</u></h1>



      <p className="user">user: {user.name}<br />
        user bio: {user.bio} <br />
        e-mail:  {user.email}</p>
      <div className="profile"><h2>Skills</h2>
      {skills.map((skill, index) => (
        <Skill key={index} name={skill.name} proficiency={skill.proficiency} />
      ))}
      <h2> Job Experiences</h2>
      {experiences.map((experience, index) => (
        <JobExperiences
          key={index}
          jobTitle={experience.jobTitle}
          companyName={experience.companyName}
          duration={experience.duration} />
      ))}
   </div>
    </><div className="Edu"><h2>Education</h2>
      {education.map((edu, index) => (
        <Education
          key={index}
          institutionName={edu.institutionName}
          degree={edu.degree}
          yearsAttended={edu.yearsAttended} />
      ))}
      </div></>)
}